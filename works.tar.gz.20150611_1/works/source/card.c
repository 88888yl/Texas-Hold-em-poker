/** 
 * Create by myl 
 * in 2015-5-20 
 */

#include "game.h"
#include "card.h"

int 
analyse_cur_cards(struct card all_cards[], int cards_num) 
{
	int point_array[15] = {0};
	int color_array[4]  = {0};

	if (is_royal_straight_flush(all_cards, cards_num))
		return royal_straight_flush;
	if (is_straight_flush(all_cards, cards_num, point_array, color_array))
		return straight_flush;
	if (is_four_of_a_kind(all_cards, cards_num, point_array))
		return four_of_a_kind;
	if (is_full_house(all_cards, cards_num, point_array))
		return full_house;
}

int 
big_cards(struct card all_cards[], int cards_num) 
{
	int point_array[15] = {0};
	int color_array[4]  = {0};

	if (is_royal_straight_flush(all_cards, cards_num))
		return royal_straight_flush;
	if (is_straight_flush(all_cards, cards_num, point_array, color_array))
		return straight_flush;
	if (is_four_of_a_kind(all_cards, cards_num, point_array))
		return four_of_a_kind;
	if (is_full_house(all_cards, cards_num, point_array))
		return full_house;
	if (is_flush(all_cards, cards_num, color_array))
		return flush;
	if (is_straight(all_cards, cards_num, point_array))
		return straight;
	if (is_three_of_a_kind(all_cards, cards_num, point_array))
		return three_of_a_kind;
	if (is_two_pair(all_cards, cards_num, point_array))
		return two_pair;
	return normal_cards;
}

int  
pre_flop_bet() 
{
	int i, j, retval;
	int betted_player_num 	= 0;
	int inquire_player_num 	= cur_inquire.cur_player_num;
	int total_pot 			= cur_inquire.total_pot;
	int my_jetton 			= 0;
	int my_money 			= 0;
	int raise_num 			= 0;

	int all_fold 			= 1;
	int one_call 			= 0;
	int more_call 			= 0;
	int one_raise_no_call 	= 0;
	int one_raise_more_call = 0;
	int has_raise			= 0;
	int only_check			= 1;

	int check_raise			= 0;

	/** get my own bet info */
	if (inquire_rounds == 1) {
		betted_player_num = cur_seat.cur_player_num;
		for (i = 0; i < betted_player_num; ++i) {
			if (cur_seat.players[i].player_id == my_player_id) {
				my_jetton = cur_seat.players[i].jetton;
				my_money = cur_seat.players[i].money;
			}
		}
	} else {
		betted_player_num = cur_inquire.cur_player_num;
		for (i = 0; i < betted_player_num; ++i) {
			if (cur_inquire.cur_states[i].m_player_info.player_id == my_player_id) {
				my_jetton = cur_inquire.cur_states[i].m_player_info.jetton;
				my_money = cur_inquire.cur_states[i].m_player_info.money;
			}
		}
	}

	/** get other players' action */
	for (i = 0; i < inquire_player_num; ++i) {
		if (cur_inquire.cur_states[i].action_num != FOLD_ACTION)
			if (cur_inquire.cur_states[i].action_num != BLIND_ACTION)
				all_fold = 0;
		if (cur_inquire.cur_states[i].action_num == CALL_ACTION)
			++more_call;
		if (cur_inquire.cur_states[i].action_num == RAISE_ACTION) {
			one_raise_more_call = 1;
			has_raise = 1;
		}
		if (cur_inquire.cur_states[i].action_num != CHECK_ACTION && cur_inquire.cur_states[i].action_num != FOLD_ACTION)
			only_check = 0;
	}
	if (more_call == 1)
		one_call = 1;
	if (!more_call && one_raise_more_call)
		one_raise_no_call = 1;
	if (one_raise_no_call)
		one_raise_more_call = 0;

	/**  find current bet */
	if ((raise_num = find_bet()) <= 0) {
		fprintf(stderr, "no inquire bet msg.\n");
		return FOLD_ACTION;
	}

	/** win the blind jetton */
	if (inquire_rounds == 1 && my_seat == BACK_SEAT && all_fold) {
		return raise_num;
	} else if (inquire_rounds > 1 && all_fold) {
		return raise_num;
	}

	if (great_hole_cards(all_cards)) {
		switch (my_seat) {
			case SMALL_BLIND_SEAT:
			case BIG_BLIND_SEAT:
			case FRONT_SEAT:
			case MIDDLE_SEAT:
			{
				if (inquire_rounds < 5) {
					return CALL_ACTION;
				}
				return raise_num * 2;
				break;
			}
			case BACK_SEAT:
			{
				if (all_fold)
					return raise_num * 2;
				else if (one_call || more_call) {
					if (inquire_rounds < 5)
						return CALL_ACTION;
					return raise_num * 2;
				}
				else if (one_raise_no_call) {
					return raise_num * 2;
				}
				else if (one_raise_more_call) {
					if (inquire_rounds < 5)
						return CALL_ACTION;
					return raise_num * 2;
				} else if (only_check) {
					if (all_cards[0].m_point == all_cards[1].m_point) {
						return raise_num * 2;
					} else {
						return CHECK_ACTION;
					}
				} else {
					return raise_num;
				}
				break;
			}
		}
	} else if (big_hole_cards(all_cards)) {
		switch (my_seat) {
			case SMALL_BLIND_SEAT:
			{
				if (all_fold) {
					return raise_num * 2;
				} else if (one_call || more_call || !has_raise) {
					return raise_num;
				} else if (has_raise || one_raise_no_call) {
					if (inquire_rounds > 3) {
						for (i = 0; i < cur_inquire.cur_player_num; ++i) {
							if (cur_inquire.cur_states[i].action_num == ALLIN_ACTION 
								|| cur_inquire.cur_states[i].action_num == RAISE_ACTION)
							{
								for (j = 0; j < 8; ++j) {
									if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
										if (cur_features[j].like_character == CONSERVATIVE) {
											if (raise_num < (my_jetton / 4)) {
												return FOLD_ACTION;
											}
										}
									}
								}
							}
						}
						return CALL_ACTION;
					} else {
						return raise_num;
					}
				} else if (one_raise_more_call) {
					return CALL_ACTION;
				} else if (only_check) {
					if (all_cards[0].m_point == all_cards[1].m_point && all_cards[0].m_point >= POINT_10) {
						return raise_num * 2;
					} else {
						return CHECK_ACTION;
					}
				} else {
					return CHECK_ACTION;
				}
				break;
			}
			case BIG_BLIND_SEAT:
			{
				if (all_fold) {
					return raise_num * 2;
				} else if (one_call || more_call || !has_raise) {
					return raise_num;
				} else if (one_raise_no_call) {
					if (inquire_rounds > 3) {
						for (i = 0; i < cur_inquire.cur_player_num; ++i) {
							if (cur_inquire.cur_states[i].action_num == ALLIN_ACTION 
								|| cur_inquire.cur_states[i].action_num == RAISE_ACTION)
							{
								for (j = 0; j < 8; ++j) {
									if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
										if (cur_features[j].like_character == CONSERVATIVE)
											if (raise_num < (my_jetton / 4)) {
												return FOLD_ACTION;
											}
									}
								}
							}
						}
						return raise_num;
					} else {
						return raise_num;
					}
				} else if (one_raise_more_call) {
					return CALL_ACTION;
				} else if (only_check) {
					if (all_cards[0].m_point == all_cards[1].m_point && all_cards[0].m_point >= POINT_10) {
						return raise_num * 2;
					} else {
						return CHECK_ACTION;
					}
				} else {
					return CHECK_ACTION;
				}
				break;
			}
			case FRONT_SEAT:
			{
				if (all_fold || one_call || more_call || !has_raise) {
					return raise_num;
				} else if (one_raise_no_call) {
					if (inquire_rounds > 3) {
						return FOLD_ACTION;
					}
				} else if (one_raise_more_call) {
					return CALL_ACTION;
				} else if (only_check) {
					if (all_cards[0].m_point == all_cards[1].m_point && all_cards[0].m_point >= POINT_10) {
						return raise_num * 2;
					} else {
						return CHECK_ACTION;
					}
				} else {
					return CHECK_ACTION;
				}
				break;
			}
			case MIDDLE_SEAT:
			{
				if (all_fold || one_call || more_call || !has_raise) {
					return raise_num;
				} else if (one_raise_no_call) {
					return raise_num;
				} else if (one_raise_more_call) {
					return CALL_ACTION;
				} else if (only_check) {
					if (all_cards[0].m_point == all_cards[1].m_point && all_cards[0].m_point >= POINT_10) {
						return raise_num * 2;
					} else {
						return CHECK_ACTION;
					}
				} else {
					return CHECK_ACTION;
				}
				break;
			}
			case BACK_SEAT:
			{
				if (all_fold || one_call || more_call || !has_raise) {
					return raise_num;
				} else if (one_raise_no_call) {
					if (inquire_rounds > 3) {
						for (i = 0; i < cur_inquire.cur_player_num; ++i) {
							if (cur_inquire.cur_states[i].action_num == ALLIN_ACTION 
								|| cur_inquire.cur_states[i].action_num == RAISE_ACTION)
							{
								for (j = 0; j < 8; ++j) {
									if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
										if (cur_features[j].like_character == CONSERVATIVE)
											if (raise_num < (my_jetton / 4)) {
												return FOLD_ACTION;
											}
									}
								}
							}
						}
						return raise_num;
					} else {
						return raise_num;
					}
				} else if (one_raise_more_call) {
					return CALL_ACTION;
				} else if (only_check) {
					if (all_cards[0].m_point == all_cards[1].m_point && all_cards[0].m_point >= POINT_10) {
						return raise_num * 2;
					} else {
						return CHECK_ACTION;
					}
				} else {
					return CHECK_ACTION;
				}
				break;
			}
		}
	} else if (middle_hole_cards(all_cards)) {
		switch (my_seat) {
			case SMALL_BLIND_SEAT:
			{
				if (all_fold || one_call || more_call || !has_raise) {
					return raise_num;
				} else if (one_raise_no_call) {
					return FOLD_ACTION;
				} else if (one_raise_more_call) {
					if (all_cards[0].m_color == all_cards[1].m_color) {
						if (all_cards[0].m_point == POINT_K && all_cards[1].m_point == POINT_Q
						 || all_cards[0].m_point == POINT_Q && all_cards[1].m_point == POINT_K)
							return CALL_ACTION;
					}
					return FOLD_ACTION;
				} else if (only_check) {
					return CHECK_ACTION;
				} else {
					return FOLD_ACTION;
				}
				break;
			}
			case BIG_BLIND_SEAT:
			{
				if (all_fold || one_call || more_call || !has_raise) {
					return raise_num;
				} else if (one_raise_no_call) {
					if (inquire_rounds > 3) {
						for (i = 0; i < cur_inquire.cur_player_num; ++i) {
							if (cur_inquire.cur_states[i].action_num == ALLIN_ACTION 
								|| cur_inquire.cur_states[i].action_num == RAISE_ACTION)
							{
								for (j = 0; j < 8; ++j) {
									if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
										if (cur_features[j].like_character == CONSERVATIVE)
											if (raise_num < (my_jetton / 4)) {
												return FOLD_ACTION;
											}
									}
								}
							}
						}
						return CALL_ACTION;
					} else {
						return CALL_ACTION;
					}
				} else if (one_raise_more_call) {
					return CALL_ACTION;
				} else if (only_check) {
					return CHECK_ACTION;
				} else {
					return FOLD_ACTION;
				}
				break;
			}
			case FRONT_SEAT:
			{
				if (one_raise_more_call) {
					if (all_cards[0].m_color == all_cards[1].m_color) {
						if (all_cards[0].m_point == POINT_K && all_cards[1].m_point == POINT_Q
						 || all_cards[0].m_point == POINT_Q && all_cards[1].m_point == POINT_K)
							return CALL_ACTION;
					}	
				}
				if (inquire_rounds == 1) {
					return FOLD_ACTION;
				}
				else {
					if (all_fold)
						return raise_num;
					return FOLD_ACTION;
				}
				break;
			}
			case MIDDLE_SEAT:
			case BACK_SEAT:
			{
				if (all_fold || one_call || more_call || !has_raise) {
					return raise_num;
				} else if (one_raise_no_call) {
					return FOLD_ACTION;
				} else if (one_raise_more_call) {
					if (all_cards[0].m_color == all_cards[1].m_color) {
						if (all_cards[0].m_point == POINT_K && all_cards[1].m_point == POINT_Q
						 || all_cards[0].m_point == POINT_Q && all_cards[1].m_point == POINT_K)
							return CALL_ACTION;
					}
					return FOLD_ACTION;
				} else if (only_check) {
					return CHECK_ACTION;
				} else {
					return FOLD_ACTION;
				}
				break;
			}
		}
	} else if (speculative_hole_cards(all_cards)) {
		switch (my_seat) {
			case SMALL_BLIND_SEAT:
			{
				if (all_fold) {
					return raise_num;
				} else if (one_call || more_call || one_raise_more_call) {
					if (inquire_rounds > 2) {
						for (i = 0; i < cur_inquire.cur_player_num; ++i) {
							if (cur_inquire.cur_states[i].action_num == ALLIN_ACTION 
								|| cur_inquire.cur_states[i].action_num == RAISE_ACTION)
							{
								for (j = 0; j < 8; ++j) {
									if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
										if (cur_features[j].like_character == CONSERVATIVE)
											if (raise_num < (my_jetton / 4)) {
												return FOLD_ACTION;
											}
									}
								}
							}
						}
						return CALL_ACTION;
					} else {
						return CALL_ACTION;
					}
				} else if (one_raise_no_call) {
					return FOLD_ACTION;
				} else if (only_check) {
					return CHECK_ACTION;
				} else {
					if (all_cards[0].m_point == all_cards[1].m_point)
						return CHECK_ACTION;
					return FOLD_ACTION;
				}
				break;
			}
			case BIG_BLIND_SEAT:
			{
				if (all_fold) {
					return raise_num;
				} else if (one_call || more_call) {
					return CHECK_ACTION;
				} else if (one_raise_no_call || one_raise_more_call) {
					if (inquire_rounds > 2) {
						for (i = 0; i < cur_inquire.cur_player_num; ++i) {
							if (cur_inquire.cur_states[i].action_num == ALLIN_ACTION 
								|| cur_inquire.cur_states[i].action_num == RAISE_ACTION)
							{
								for (j = 0; j < 8; ++j) {
									if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
										if (cur_features[j].like_character == CONSERVATIVE)
											if (raise_num < (my_jetton / 4)) {
												return FOLD_ACTION;
											}
									}
								}
							}
						}
						return CALL_ACTION;
					} else {
						return CALL_ACTION;
					}
				} else if (only_check) {
					return CHECK_ACTION;
				} else {
					if (all_cards[0].m_point == all_cards[1].m_point)
						return CHECK_ACTION;
					return FOLD_ACTION;
				}
				break;
			}
			case FRONT_SEAT:
			{
				if (one_call || one_raise_no_call) {
					return FOLD_ACTION;
				} else if (more_call || one_raise_more_call) {
					return CALL_ACTION;
				} else if (all_fold) {
					if (inquire_rounds == 1) {
						return FOLD_ACTION;
					}
					else
						return raise_num;
				} else {
					return FOLD_ACTION;
				}
				break;
			}
			case MIDDLE_SEAT:
			{
				if (one_call || one_raise_no_call) {
					return FOLD_ACTION;
				} else if (more_call || one_raise_more_call) {
					return CALL_ACTION;
				} else if (all_fold) {
					if (inquire_rounds == 1) {
						return FOLD_ACTION;
					}
					else
						return raise_num;
				} else {
					return FOLD_ACTION;
				}
				break;
			}
			case BACK_SEAT:
			{
				if (all_fold) {
					return raise_num;
				} else if (one_call || more_call || one_raise_more_call) {
					if (inquire_rounds > 3) {
						for (i = 0; i < cur_inquire.cur_player_num; ++i) {
							if (cur_inquire.cur_states[i].action_num == ALLIN_ACTION 
								|| cur_inquire.cur_states[i].action_num == RAISE_ACTION)
							{
								for (j = 0; j < 8; ++j) {
									if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
										if (cur_features[j].like_character == CONSERVATIVE)
											if (raise_num < (my_jetton / 4)) {
												return FOLD_ACTION;
											}
									}
								}
							}
						}
						return CALL_ACTION;
					} else {
						return CALL_ACTION;
					}
				} else if (one_raise_no_call) {
					return FOLD_ACTION;
				} else {
					return FOLD_ACTION;
				}
				break;
			}
		}
	} else if (mixed_hole_cards(all_cards)) {
		switch (my_seat) {
			case SMALL_BLIND_SEAT:
			{
				if (all_fold) {
					return raise_num;
				} else if (one_call || more_call || !has_raise) {
					return CALL_ACTION;
				} else if (one_raise_no_call || one_raise_more_call) {
					return FOLD_ACTION;
				}
				break;
			}
			case BIG_BLIND_SEAT:
			{
				if (all_fold) {
					return raise_num;
				} else if (one_call || more_call || !has_raise) {
					return CHECK_ACTION;
				} else if (one_raise_no_call || one_raise_more_call) {
					return FOLD_ACTION;
				} else {
					return FOLD_ACTION;
				}
				break;
			}
			case FRONT_SEAT:
			case MIDDLE_SEAT:
			{
				if (all_fold) {
					if (inquire_rounds == 1) {
						return FOLD_ACTION;
					}
					else
						return raise_num;
				}
				return FOLD_ACTION;
			}
			case BACK_SEAT:
			{
				if (all_fold) {
					return raise_num;
				} else if (more_call  || !has_raise) {
					return CHECK_ACTION;
				} else if (one_call || one_raise_no_call || one_raise_more_call) {
					return FOLD_ACTION;
				} else {
					return FOLD_ACTION;
				}
				break;
			}
		}
	}
	return FOLD_ACTION;	
}

int  
flop_bet() 
{
	int point_array[15] 	= {0};
	int i, j, cur_bet, how_big = 0;
	int inquire_player_num 	= cur_inquire.cur_player_num;
	int pos1 				= 0;
	int pos2 				= 0;
	int my_jetton 			= 0;
	int my_money 			= 0;
	int betted_player_num   = 0;

	int all_fold 			= 1;
	int one_call 			= 0;
	int more_call 			= 0;
	int one_raise_no_call 	= 0;
	int one_raise_more_call = 0;
	int has_raise			= 0;
	int only_check			= 1;

	int check_raise			= 0;

	// get some info from inquire or seat msg
	if (inquire_rounds == 1) {
		betted_player_num = cur_seat.cur_player_num;
		for (i = 0; i < betted_player_num; ++i) {
			if (cur_seat.players[i].player_id == my_player_id) {
				my_jetton = cur_seat.players[i].jetton;
				my_money = cur_seat.players[i].money;
			}
		}
	} else {
		betted_player_num = cur_inquire.cur_player_num;
		for (i = 0; i < betted_player_num; ++i) {
			if (cur_inquire.cur_states[i].m_player_info.player_id == my_player_id) {
				my_jetton = cur_inquire.cur_states[i].m_player_info.jetton;
				my_money = cur_inquire.cur_states[i].m_player_info.money;
			}
		}
	}

	// from inquire msg, get players' action whose seat before mine
	for (i = 0; i < cur_inquire.cur_player_num; ++i) {
		if (cur_inquire.cur_states[i].action_num != FOLD_ACTION)
			if (cur_inquire.cur_states[i].action_num != BLIND_ACTION)
				all_fold = 0;
		if (cur_inquire.cur_states[i].action_num == CALL_ACTION)
			++more_call;
		if (cur_inquire.cur_states[i].action_num == RAISE_ACTION) {
			one_raise_more_call = 1;
			has_raise = 1;
		}
		if (cur_inquire.cur_states[i].action_num != CHECK_ACTION && cur_inquire.cur_states[i].action_num != FOLD_ACTION)
			only_check = 0;
	}
	if (more_call == 1)
		one_call = 1;
	if (!more_call && one_raise_more_call)
		one_raise_no_call = 1;
	if (one_raise_no_call)
		one_raise_more_call = 0;

	// find current bet
	if ((cur_bet = find_bet()) <= 0) {
		fprintf(stderr, "no inquire bet msg.\n");
		return FOLD_ACTION;
	}

	// big cards, check one time, then raise forever
	how_big = big_cards(all_cards, 5);

	if (how_big < flush) {
		if (inquire_rounds == 1)
			return CALL_ACTION;
		return cur_bet * 2;
	} else {
		/** one check and raise again seems that one has big cards */
		if (inquire_rounds == 1) {
			for (i = 0; i < inquire_player_num; ++i) {
				if (cur_inquire.cur_states[i].action_num == CHECK_ACTION) {
					check_raise_man.player_id[i] = cur_inquire.cur_states[i].m_player_info.player_id;
				} else {
					check_raise_man.player_id[i] = 0;
				}
			}
		} else if (inquire_rounds == 2) {
			for (i = 0; i < inquire_player_num; ++i) {
				if (cur_inquire.cur_states[i].action_num == RAISE_ACTION) {
					for (j = 0; j < 8; ++j) {
						if (check_raise_man.player_id[j] == cur_inquire.cur_states[i].m_player_info.player_id) {
							printf("flop check and raise fold!!!\n");
							return FOLD_ACTION;
						}
					}
				}
			}
		}

		if (how_big == flush || how_big == straight) {
			for (i = 0; i < 5; ++i) {
				if (all_cards[i].m_point >= POINT_Q) {
					if (inquire_rounds == 1)
						return CHECK_ACTION;
					if (inquire_rounds == 2)
						return CALL_ACTION;
					return cur_bet * 2;
				}
			}
			if (inquire_rounds == 1)
				return cur_bet * 2;
			if (all_fold)
				return cur_bet * 2;
			else if (one_raise_no_call) {
				for (i = 0; i < cur_inquire.cur_player_num; ++i) {
					if (cur_inquire.cur_states[i].action_num == ALLIN_ACTION 
						|| cur_inquire.cur_states[i].action_num == RAISE_ACTION)
					{
						for (j = 0; j < 8; ++j) {
							if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
								if (cur_features[j].like_character == CONSERVATIVE)
									if (cur_bet < (my_jetton / 4)){
										printf("flush straight card fold!!\n");
										return FOLD_ACTION;
									}
							}
						}
					}
				}
				return cur_bet;
			} else if (has_raise) {
				if (inquire_rounds < 3)
					return cur_bet;
				else {
					for (i = 0; i < cur_inquire.cur_player_num; ++i) {
						if (cur_inquire.cur_states[i].action_num == ALLIN_ACTION 
							|| cur_inquire.cur_states[i].action_num == RAISE_ACTION)
						{
							for (j = 0; j < 8; ++j) {
								if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
									if (cur_features[j].like_character == CONSERVATIVE)
										if (cur_bet < (my_jetton / 4)) {
											printf("flush straight card fold!!\n");
											return FOLD_ACTION;
										}
								}
							}
						}
					}
					return cur_bet;
				}
			} else if (only_check) {
				return cur_bet;
			} else {
				return CALL_ACTION;
			}
		} else if (how_big == three_of_a_kind) {
			save_point(all_cards, 5, point_array);
			for (i = 2; i < 15; ++i) {
				if (point_array[i] == 3 && i >= POINT_Q) {
					if (has_raise) {
						for (i = 0; i < cur_inquire.cur_player_num; ++i) {
							if (cur_inquire.cur_states[i].action_num == ALLIN_ACTION 
								|| cur_inquire.cur_states[i].action_num == RAISE_ACTION)
							{
								for (j = 0; j < 8; ++j) {
									if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
										if (cur_features[j].like_character == CONSERVATIVE)
											if (cur_bet < (my_jetton / 4)) {
												printf("three_of_a_kind card fold!!\n");
												return FOLD_ACTION;
											}
									}
								}
							}
						}
						return cur_bet;
					} else if (only_check) {
						return cur_bet;
					} else {
						return CALL_ACTION;
					}
					break;
				}
			}
			if (inquire_rounds == 1) {
				return CALL_ACTION;
			} else {
				if (all_fold)
					return cur_bet * 2;
				else if (has_raise) {
					for (i = 0; i < cur_inquire.cur_player_num; ++i) {
						if (cur_inquire.cur_states[i].action_num == ALLIN_ACTION 
							|| cur_inquire.cur_states[i].action_num == RAISE_ACTION)
						{
							for (j = 0; j < 8; ++j) {
								if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
									if (cur_features[j].like_character == CONSERVATIVE)
										if (cur_bet < (my_jetton / 4)) {
											printf("three_of_a_kind card fold!!\n");
											return FOLD_ACTION;
										}
								}
							}
							for (j = 0; j < 8; ++j) {
								if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
									if (cur_features[j].like_character == REGULAR)
										if (inquire_rounds > 2 && cur_bet < (my_jetton / 4)) {
											printf("three_of_a_kind card fold!!\n");
											return FOLD_ACTION;
										}
								}
							}
						}
					}
					return cur_bet;
				} else if (only_check) {
					if (inquire_rounds == 1)
						return cur_bet;
					return cur_bet * 2;
				} else {
					return CALL_ACTION;
				}
			}
		} else if (how_big == two_pair) {
			for (i = 2; i < 5; ++i) {
				for (j = 2; j < 5; ++j) {
					if (i != j && all_cards[i].m_point == all_cards[j].m_point)
						goto flop_one_pair;
				}
			}
		
			save_point(all_cards, 5, point_array);
			for (i = 2; i < 15; ++i) {
				if (point_array[i] == 2) {					
					if (pos1 == 0)
						pos1 = i;
					else {
						pos2 = i;
						if (pos1 >= POINT_Q || pos2 >= POINT_Q) {
							if (all_fold)
								return cur_bet * 2;
							else if (has_raise) {
								for (i = 0; i < cur_inquire.cur_player_num; ++i) {
									if (cur_inquire.cur_states[i].action_num == ALLIN_ACTION 
										|| cur_inquire.cur_states[i].action_num == RAISE_ACTION)
									{
										for (j = 0; j < 8; ++j) {
											if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
												if (cur_features[j].like_character == CONSERVATIVE)
													if (cur_bet < (my_jetton / 4)) {
														printf("two_pair card fold!!\n");
														return FOLD_ACTION;
													}
											}
										}
										for (j = 0; j < 8; ++j) {
											if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
												if (cur_features[j].like_character == REGULAR)
													if (inquire_rounds > 2 && cur_bet < (my_jetton / 4)) {
														printf("two_pair card fold!!\n");
														return FOLD_ACTION;
													}
											}
										}
									}
								}
								return cur_bet;
							} else if (only_check) {
								if (inquire_rounds == 1)
									return cur_bet;
								return cur_bet * 2;
							} else {
								return CALL_ACTION;
							}
						}
					}
				}
			}

			if (inquire_rounds == 1) {
				return CALL_ACTION;
			} else {
				if (all_fold)
					return cur_bet * 2;
				else if (has_raise) {
					for (i = 0; i < cur_inquire.cur_player_num; ++i) {
						if (cur_inquire.cur_states[i].action_num == ALLIN_ACTION 
							|| cur_inquire.cur_states[i].action_num == RAISE_ACTION)
						{
							for (j = 0; j < 8; ++j) {
								if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
									if (cur_features[j].like_character == CONSERVATIVE)
										if (cur_bet < (my_jetton / 4)) {
											printf("two_pair card fold!!\n");
											return FOLD_ACTION;
										}
								}
							}
							for (j = 0; j < 8; ++j) {
								if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
									if (cur_features[j].like_character == REGULAR)
										if (inquire_rounds > 2 && cur_bet < (my_jetton / 4)) {
											printf("two_pair card fold!!\n");
											return FOLD_ACTION;
										}
								}
							}
						}
					}
					return cur_bet;
				} else if (only_check) {
					if (inquire_rounds == 1)
						return cur_bet;
					return cur_bet * 2;
				} else {
					return CALL_ACTION;
				}
			}
		}
	}

	if (is_one_pair(all_cards, 5, point_array)) {
flop_one_pair:
		for (i = 2; i < 5; ++i) {
			for (j = 2; j < 5; ++j) {
				if (i != j && all_cards[i].m_point == all_cards[j].m_point)
					goto flop_other_cards;
			}
		}

		save_point(all_cards, 5, point_array);
		if (inquire_rounds == 1) {
			switch (my_seat) {
				case SMALL_BLIND_SEAT:
				case BIG_BLIND_SEAT:
				case FRONT_SEAT:
				case MIDDLE_SEAT:
				{
					return CALL_ACTION;
				}
				case BACK_SEAT:
				{
					if (only_check) {
						return cur_bet;
					} else if (!has_raise) {
						return cur_bet;
					} else if (one_raise_no_call || one_raise_more_call) {
						for (i = 0; i < cur_inquire.cur_player_num; ++i) {
							if (cur_inquire.cur_states[i].action_num == ALLIN_ACTION 
								|| cur_inquire.cur_states[i].action_num == RAISE_ACTION)
							{
								for (j = 0; j < 8; ++j) {
									if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
										if (cur_features[j].like_character == CONSERVATIVE)
											if (cur_bet < (my_jetton / 4)) {
												printf("one_pair card fold!!\n");
												return FOLD_ACTION;
											}
									}
								}
							}
						}
						return cur_bet;
					} else {
						if (cur_bet < (my_jetton / 6)) {
							printf("one_pair card fold!!\n");
							return FOLD_ACTION;
						}
					}
				}
			}
		} else {
			for (i = 2; i < 15; ++i) {
				if (point_array[i] == 2 && i >= 12) {
					if (cur_bet > (my_jetton / 4)) {
						return CALL_ACTION;
					} else {
						if (!has_raise)
							return cur_bet;
						else if (one_raise_no_call || one_raise_more_call) {
							for (i = 0; i < cur_inquire.cur_player_num; ++i) {
								if (cur_inquire.cur_states[i].action_num == ALLIN_ACTION 
									|| cur_inquire.cur_states[i].action_num == RAISE_ACTION)
								{
									for (j = 0; j < 8; ++j) {
										if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
											if (cur_features[j].like_character == CONSERVATIVE) {
												printf("one_pair card fold!!\n");
												return FOLD_ACTION;
											}
										}
									}
								}
							}
							return CALL_ACTION;
						} else {
							return FOLD_ACTION;
						}
					}
				} else if (point_array[i] == 2 && i > 5 && i < 12) {
					if (cur_bet < (my_jetton / 4)) {
						if (has_raise)
							return FOLD_ACTION;
						return CALL_ACTION;
					} else {
						if (one_raise_no_call) {
							for (i = 0; i < cur_inquire.cur_player_num; ++i) {
								if (cur_inquire.cur_states[i].action_num == ALLIN_ACTION 
									|| cur_inquire.cur_states[i].action_num == RAISE_ACTION)
								{
									for (j = 0; j < 8; ++j) {
										if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
											if (cur_features[j].like_character == CONSERVATIVE || cur_features[j].like_character == REGULAR) {
												printf("one_pair card fold!!\n");
												return FOLD_ACTION;
											}
										}
									}
								}
							}
							return CALL_ACTION;
						} else if (!has_raise) {
							return CALL_ACTION;
						} else {
							printf("one_pair card fold!!\n");
							return FOLD_ACTION;
						}
					}
				} else if (point_array[i] == 2 && i <= 5) {
					if (!has_raise && cur_bet > (my_jetton / 4))
						return CALL_ACTION;
					else {
						printf("one_pair card fold!!\n");
						return FOLD_ACTION;
					}
				} else {
					return FOLD_ACTION;
				}
			}
		}
	}
	goto flop_other_cards;

flop_other_cards:
	if (inquire_rounds == 1) {
		switch (my_seat) {
			case SMALL_BLIND_SEAT:
			case BIG_BLIND_SEAT:
			{
				if (cur_bet < (my_jetton / 4))
					return CHECK_ACTION;
				else {
					if (!has_raise)
						return CHECK_ACTION;
					else {
						printf("other card fold!!\n");
						return FOLD_ACTION;
					}
				}
			}
			case FRONT_SEAT:
			case MIDDLE_SEAT:
			{
				if (only_check)
					return CHECK_ACTION;
				else {
					if (!has_raise) {
						if (cur_bet < (my_jetton / 4)) {
							printf("other card fold!!\n");
							return FOLD_ACTION;
						}
						else
							return CHECK_ACTION;
					} else {
						printf("other card fold!!\n");
						return FOLD_ACTION;
					}
				}
				break;
			}
			case BACK_SEAT:
			{
				if (cur_bet < (my_jetton / 4))
					return CHECK_ACTION;
				else {
					if (!has_raise)
						return CHECK_ACTION;
					else {
						printf("other card fold!!\n");
						return FOLD_ACTION;
					}
				}
				break;
			}
		}
	} else {
		if (cur_bet < (my_jetton / 4))
			return CHECK_ACTION;
		else {
			if (only_check)
				return CHECK_ACTION;
			else {
				printf("other card fold!!\n");
				return FOLD_ACTION;
			}
		}
	}
}

int  
turn_bet() 
{
	int point_array[15] 	= {0};
	int i, j, cur_bet, how_big = 0;
	int inquire_player_num 	= cur_inquire.cur_player_num;
	int pos1 				= 0;
	int pos2 				= 0;
	int my_jetton 			= 0;
	int my_money 			= 0;
	int betted_player_num   = 0;
	int conservative_num	= 0;

	int all_fold 			= 1;
	int one_call 			= 0;
	int more_call 			= 0;
	int one_raise_no_call 	= 0;
	int one_raise_more_call = 0;
	int has_raise			= 0;
	int only_check			= 1;

	int check_raise			= 0;

	// get some info from inquire or seat msg
	if (inquire_rounds == 1) {
		betted_player_num = cur_seat.cur_player_num;
		for (i = 0; i < betted_player_num; ++i) {
			if (cur_seat.players[i].player_id == my_player_id) {
				my_jetton = cur_seat.players[i].jetton;
				my_money = cur_seat.players[i].money;
			}
		}
	} else {
		betted_player_num = cur_inquire.cur_player_num;
		for (i = 0; i < betted_player_num; ++i) {
			if (cur_inquire.cur_states[i].m_player_info.player_id == my_player_id) {
				my_jetton = cur_inquire.cur_states[i].m_player_info.jetton;
				my_money = cur_inquire.cur_states[i].m_player_info.money;
			}
		}
	}

	// from inquire msg, get players' action whose seat before mine
	for (i = 0; i < cur_inquire.cur_player_num; ++i) {
		if (cur_inquire.cur_states[i].action_num != FOLD_ACTION)
			if (cur_inquire.cur_states[i].action_num != BLIND_ACTION)
				all_fold = 0;
		if (cur_inquire.cur_states[i].action_num == CALL_ACTION)
			++more_call;
		if (cur_inquire.cur_states[i].action_num == RAISE_ACTION) {
			one_raise_more_call = 1;
			has_raise = 1;
		}
		if (cur_inquire.cur_states[i].action_num != CHECK_ACTION && cur_inquire.cur_states[i].action_num != FOLD_ACTION)
			only_check = 0;
	}
	if (more_call == 1)
		one_call = 1;
	if (!more_call && one_raise_more_call)
		one_raise_no_call = 1;
	if (one_raise_no_call)
		one_raise_more_call = 0;

	// find current bet
	if ((cur_bet = find_bet()) <= 0) {
		fprintf(stderr, "no inquire bet msg.\n");
		return FOLD_ACTION;
	}

	how_big = big_cards(all_cards, 6);
	if ((cur_bet = find_bet()) <= 0) {
		fprintf(stderr, "no inquire bet msg.\n");
		return FOLD_ACTION;
	}

	if (how_big < flush) {
		switch (inquire_rounds) {
			case 1:  return CALL_ACTION;
			case 2:  return CHECK_ACTION;
			case 3:  return cur_bet * 2;
			default: return CHECK_ACTION;
		}
	} else {
		/** one check and raise again seems that one has big cards */
		if (inquire_rounds == 1) {
			for (i = 0; i < inquire_player_num; ++i) {
				if (cur_inquire.cur_states[i].action_num == CHECK_ACTION) {
					check_raise_man.player_id[i] = cur_inquire.cur_states[i].m_player_info.player_id;
				} else {
					check_raise_man.player_id[i] = 0;
				}
			}
		} else if (inquire_rounds == 2) {
			for (i = 0; i < inquire_player_num; ++i) {
				if (cur_inquire.cur_states[i].action_num == RAISE_ACTION) {
					for (j = 0; j < 8; ++j) {
						if (check_raise_man.player_id[j] == cur_inquire.cur_states[i].m_player_info.player_id) {
							printf("turn check and raise fold!!!\n");
							return FOLD_ACTION;
						}
					}
				}
			}
		}

		if (how_big == flush || how_big == straight) {
			if (inquire_rounds == 1) {
				switch (my_seat) {
					case SMALL_BLIND_SEAT:
					case BIG_BLIND_SEAT:
					case FRONT_SEAT:
					case MIDDLE_SEAT:
					{
						return CHECK_ACTION;
					}
					case BACK_SEAT:
					{
						if (one_raise_no_call || one_raise_more_call) {
							for (i = 0; i < cur_inquire.cur_player_num; ++i) {
								if (cur_inquire.cur_states[i].action_num == ALLIN_ACTION 
									|| cur_inquire.cur_states[i].action_num == RAISE_ACTION)
								{
									for (j = 0; j < 8; ++j) {
										if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
											if (cur_features[j].like_character == CONSERVATIVE) {
												return CHECK_ACTION;
											}
										}
									}
								}
							}
							return CALL_ACTION;
						} else if (has_raise) {
							for (i = 0; i < cur_inquire.cur_player_num; ++i) {
								if (cur_inquire.cur_states[i].action_num == ALLIN_ACTION 
									|| cur_inquire.cur_states[i].action_num == RAISE_ACTION)
								{
									for (j = 0; j < 8; ++j) {
										if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
											if (cur_features[j].like_character == CONSERVATIVE) {
												++conservative_num;
											}
										}
									}
								}
							}
							if (conservative_num > 1) {
								if (cur_bet < (my_jetton / 4)) {
									printf("turn fold...\n");
									return FOLD_ACTION;
								}
							}
							return cur_bet;
						} else {
							return CHECK_ACTION;
						}
					}
				}
			} else {
				if (one_raise_no_call || one_raise_more_call) {
					for (i = 0; i < cur_inquire.cur_player_num; ++i) {
						if (cur_inquire.cur_states[i].action_num == ALLIN_ACTION 
							|| cur_inquire.cur_states[i].action_num == RAISE_ACTION)
						{
							for (j = 0; j < 8; ++j) {
								if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
									if (cur_features[j].like_character == CONSERVATIVE) {
										return CHECK_ACTION;
									}
								}
							}
						}
					}
					return CALL_ACTION;
				} else if (has_raise) {
					for (i = 0; i < cur_inquire.cur_player_num; ++i) {
						if (cur_inquire.cur_states[i].action_num == ALLIN_ACTION 
							|| cur_inquire.cur_states[i].action_num == RAISE_ACTION)
						{
							for (j = 0; j < 8; ++j) {
								if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
									if (cur_features[j].like_character == CONSERVATIVE) {
										++conservative_num;
									}
								}
							}
						}
					}
					if (conservative_num > 1 && cur_bet < (my_jetton / 4)) {
						printf("turn fold...\n");
						return FOLD_ACTION;
					}
					return cur_bet;
				} else {
					return CHECK_ACTION;
				}
			}
		} else if (how_big == three_of_a_kind) {
			if (all_cards[0].m_point == all_cards[1].m_point) {
				save_point(all_cards, 6, point_array);
				if (inquire_rounds == 1) {
					switch (my_seat) {
						case SMALL_BLIND_SEAT:
						case BIG_BLIND_SEAT:
						case FRONT_SEAT:
						case MIDDLE_SEAT:
						{
							return CHECK_ACTION;
						}
						case BACK_SEAT:
						{
							for (i = 2; i < 15; ++i) {
								if (point_array[i] == 3 && i < POINT_Q) {
									if (has_raise) {
										for (i = 0; i < cur_inquire.cur_player_num; ++i) {
											if (cur_inquire.cur_states[i].action_num == ALLIN_ACTION 
												|| cur_inquire.cur_states[i].action_num == RAISE_ACTION)
											{
												for (j = 0; j < 8; ++j) {
													if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
														if (cur_features[j].like_character == CONSERVATIVE)
															++conservative_num;
													}
												}
											}
										}
										if (conservative_num > 1 && cur_bet < (my_jetton / 4)) {
											printf("turn fold...\n");
											return FOLD_ACTION;
										}
										return CHECK_ACTION;
									} else if (only_check) {
										return cur_bet;
									} else {
										return CALL_ACTION;
									}
									break;
								} else {
									return CHECK_ACTION;
								}
							}
							return CHECK_ACTION;
						}
					}
				} else {
					for (i = 2; i < 15; ++i) {
						if (point_array[i] == 3 && i < POINT_Q) {
							if (has_raise) {
								for (i = 0; i < cur_inquire.cur_player_num; ++i) {
									if (cur_inquire.cur_states[i].action_num == ALLIN_ACTION 
										|| cur_inquire.cur_states[i].action_num == RAISE_ACTION)
									{
										for (j = 0; j < 8; ++j) {
											if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
												if (cur_features[j].like_character == CONSERVATIVE)
													++conservative_num;
											}
										}
									}
								}
								if (conservative_num > 1 && cur_bet < (my_jetton / 4)) {
									printf("turn fold...\n");
									return FOLD_ACTION;
								}
								return CHECK_ACTION;
							} else if (only_check) {
								return cur_bet;
							} else {
								return CALL_ACTION;
							}
							break;
						} else {
							return CHECK_ACTION;
						}
					}
					return CHECK_ACTION;
				}
			} else {
				if (inquire_rounds == 1) {
					switch (my_seat) {
						case SMALL_BLIND_SEAT:
						case BIG_BLIND_SEAT:
						case FRONT_SEAT:
						case MIDDLE_SEAT:
						{
							return CHECK_ACTION;
						}
						case BACK_SEAT:
						{

						}
					}
				} else {
					if (has_raise) {
						for (i = 0; i < cur_inquire.cur_player_num; ++i) {
							if (cur_inquire.cur_states[i].action_num == ALLIN_ACTION 
								|| cur_inquire.cur_states[i].action_num == RAISE_ACTION)
							{
								for (j = 0; j < 8; ++j) {
									if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
										if (cur_features[j].like_character == CONSERVATIVE || cur_features[j].like_character == REGULAR)
											++conservative_num;
									}
								}
							}
						}
						if (conservative_num == 1 && cur_bet < (my_jetton / 4)) {
							printf("turn fold...\n");
							return FOLD_ACTION;
						} else if (conservative_num > 1 && cur_bet < (my_jetton / 2)) {
							printf("turn fold...\n");
							return FOLD_ACTION;
						}
						return CHECK_ACTION;
					} else if (only_check) {
						return cur_bet;
					} else {
						return CALL_ACTION;
					}
				}
			}				
		} else if (how_big == two_pair) {
			for (i = 2; i < 6; ++i) {
				for (j = 2; j < 6; ++j) {
					if (i != j && all_cards[i].m_point == all_cards[j].m_point)
						goto turn_one_pair;
				}
			}

			if (inquire_rounds == 1) {
				switch (my_seat) {
					case SMALL_BLIND_SEAT:
					case BIG_BLIND_SEAT:
					case FRONT_SEAT:
					case MIDDLE_SEAT:
					{
						return CHECK_ACTION;
					}
					case BACK_SEAT:
					{
						if (has_raise) {
							for (i = 0; i < cur_inquire.cur_player_num; ++i) {
								if (cur_inquire.cur_states[i].action_num == ALLIN_ACTION 
									|| cur_inquire.cur_states[i].action_num == RAISE_ACTION)
								{
									for (j = 0; j < 8; ++j) {
										if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
											if (cur_features[j].like_character == CONSERVATIVE)
												++conservative_num;
										}
									}
								}
							}
							if (conservative_num > 1 && cur_bet < (my_jetton / 4)) {
								printf("turn fold...\n");
								return FOLD_ACTION;
							}
							return CHECK_ACTION;
						} else if (only_check) {
							return cur_bet;
						} else {
							return CALL_ACTION;
						}
					}
				}
			} else {
				if (has_raise) {
					for (i = 0; i < cur_inquire.cur_player_num; ++i) {
						if (cur_inquire.cur_states[i].action_num == ALLIN_ACTION 
							|| cur_inquire.cur_states[i].action_num == RAISE_ACTION)
						{
							for (j = 0; j < 8; ++j) {
								if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
									if (cur_features[j].like_character == CONSERVATIVE)
										++conservative_num;
								}
							}
						}
					}
					if (conservative_num > 1 && cur_bet < (my_jetton / 4)) {
						printf("turn fold...\n");
						return FOLD_ACTION;
					}
					return CHECK_ACTION;
				} else if (only_check) {
					return cur_bet;
				} else {
					return CALL_ACTION;
				}
			}
		}

		if (is_one_pair(all_cards, 6, point_array)) {
turn_one_pair:
			for (i = 2; i < 6; ++i) {
				for (j = 2; j < 6; ++j) {
					if (i != j && all_cards[i].m_point == all_cards[j].m_point)
						goto turn_other_cards;
				}
			}
	
			save_point(all_cards, 5, point_array);
			if (inquire_rounds == 1) {
				switch (my_seat) {
					case SMALL_BLIND_SEAT:
					case BIG_BLIND_SEAT:
					case FRONT_SEAT:
					case MIDDLE_SEAT:
					{
						if (cur_bet < (my_jetton / 4)) {
							printf("turn one pair fold...\n");
							return FOLD_ACTION;
						}
						else {
							return CHECK_ACTION;
						}
					}
					case BACK_SEAT:
					{
						if (has_raise) {
							for (i = 0; i < cur_inquire.cur_player_num; ++i) {
								if (cur_inquire.cur_states[i].action_num == ALLIN_ACTION 
									|| cur_inquire.cur_states[i].action_num == RAISE_ACTION)
								{
									for (j = 0; j < 8; ++j) {
										if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
											if (cur_features[j].like_character == CONSERVATIVE || cur_features[j].like_character == REGULAR)
												++conservative_num;
										}
									}
								}
							}
							if (conservative_num == 1 && cur_bet < (my_jetton / 4)) {
								printf("turn one pair fold...\n");
								return FOLD_ACTION;
							}
							else if (conservative_num > 1 && cur_bet < (my_jetton / 2)) {
								printf("turn one pair fold...\n");
								return FOLD_ACTION;
							}
							else {
								if (cur_bet < (my_jetton / 4)) {
									printf("turn one pair fold...\n");
									return FOLD_ACTION;
								}
								else {
									return CHECK_ACTION;
								}
							}
						} else {
							if (cur_bet < (my_jetton / 4)) {
								printf("turn one pair fold...\n");
								return FOLD_ACTION;
							}
							else {
								return CHECK_ACTION;
							}
						}
					}
				}
			} else {
				if (has_raise) {
					for (i = 0; i < cur_inquire.cur_player_num; ++i) {
						if (cur_inquire.cur_states[i].action_num == ALLIN_ACTION 
							|| cur_inquire.cur_states[i].action_num == RAISE_ACTION)
						{
							for (j = 0; j < 8; ++j) {
								if (cur_inquire.cur_states[i].m_player_info.player_id == cur_features[j].player_id) {
									if (cur_features[j].like_character == CONSERVATIVE || cur_features[j].like_character == REGULAR)
										++conservative_num;
								}
							}
						}
					}
					if (conservative_num == 1 && cur_bet < (my_jetton / 4)) {
						printf("turn one pair fold...\n");
						return FOLD_ACTION;
					}
					else if (conservative_num > 1 && cur_bet < (my_jetton / 2)) {
						printf("turn one pair fold...\n");
						return FOLD_ACTION;
					}
					else {
						if (cur_bet < (my_jetton / 4)) {
							printf("turn one pair fold...\n");
							return FOLD_ACTION;
						}
						else {
							return CHECK_ACTION;
						}
					}
				} else {
					if (cur_bet < (my_jetton / 4)) {
						printf("turn one pair fold...\n");
						return FOLD_ACTION;
					}
					else {
						return CHECK_ACTION;
					}
				}
			}
		}
	}
	goto turn_other_cards;

turn_other_cards:
	printf("---bad choice!!!---\n");
	if (has_raise && cur_bet < (my_jetton / 2)) {
		return FOLD_ACTION;
	} else if (!only_check && cur_bet < (my_jetton / 4)) {
		return FOLD_ACTION;
	} else {
		return CHECK_ACTION;
	}
}

int  
river_bet() 
{
	int how_big;
	int i;
	int cur_bet;
	how_big = big_cards(all_cards, 6);
	if ((cur_bet = find_bet()) <= 0) {
		fprintf(stderr, "no inquire bet msg.\n");
		return FOLD_ACTION;
	}

	if (how_big < two_pair) {
		return cur_bet * 2;
	} else if (how_big == three_of_a_kind || how_big == two_pair) {
		for (i = 0; i < cur_inquire.cur_player_num; ++i)
			if (cur_inquire.cur_states[i].action_num == ALLIN_ACTION) {
				printf("river fold\n");
				return FOLD_ACTION;
			}
	}

	if (cur_inquire.total_pot <= 5 * 40) {
		printf("river fold\n");
		return FOLD_ACTION;	
	}
	else
		return CALL_ACTION;
}
